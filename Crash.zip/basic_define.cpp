#include "basic_define.h"
#include"BLOCK.h"
#include <cstdio>
#include <cstdlib>

extern BLOCK block_type[MAX_BLOCK];
DWORD starttime;
DWORD START;
DIRECTION dir[4] = { {-1,0},{1,0},{0,-1},{0,1} };
CELL map[MAX_MAP][MAX_MAP];
extern int scr_x, scr_y;

int	ChangeToScreen(int x) { return x / BLOCK_SIZE; }

void Lose() {
	system("cls");
	printf("You Died!");
	system("pause");
}

void Win() {
	system("cls");
	printf("You Win!");
	system("pause");
}

void ChangeMap(int i, int j, int B_ID)
{
	map[i][j] = map[i][j] & MASK_BLOCK ^ block_type[B_ID].id;
}

bool IsInMap(int i, int j)
{
	return i >= 0 && i < MAX_MAP && j >= 0 && j < MAX_MAP;
}

void Gotoxy(int x, int y)
{
	HANDLE handle = GetStdHandle(STD_OUTPUT_HANDLE);
	COORD pos;
	pos.X = x; pos.Y = y;
	SetConsoleCursorPosition(handle, pos);
}

int Tick(int interVal)
{
	DWORD time = GetTickCount();
	if (START - time % interVal == 0)
		return 1;
	else
		return 0;
}

int ScreenX(int x)
{
	return x - scr_x + WIN_COL * BLOCK_SIZE;
}

int ScreenY(int y)
{
	return y - scr_y + WIN_ROW * BLOCK_SIZE;
}
